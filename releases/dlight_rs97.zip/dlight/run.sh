#!/bin/sh
LD_PRELOAD=./sdlfix.so ./dlight.dge
